import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-article-author',
  templateUrl: './edit-article-author.component.html',
  styleUrls: ['./edit-article-author.component.css']
})
export class EditArticleAuthorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
