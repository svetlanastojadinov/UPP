import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-comment-article',
  templateUrl: './comment-article.component.html',
  styleUrls: ['./comment-article.component.css']
})
export class CommentArticleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
