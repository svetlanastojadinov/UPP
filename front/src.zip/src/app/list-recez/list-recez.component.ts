import { Component, OnInit } from '@angular/core';
import { RepositoryService } from '../services/repository/repository.service';

@Component({
  selector: 'app-list-recez',
  templateUrl: './list-recez.component.html',
  styleUrls: ['./list-recez.component.css']
})
export class ListRecezComponent implements OnInit {

  private rec=[];
  constructor(private repositoryService :RepositoryService) { 
   /* 
    let x = repositoryService.getTask("posting_process","Choosing_reviewers");

  x.subscribe(
    res => {
      console.log(res);
    });
*/
  }

  ngOnInit() {
    this.repositoryService.getRecezenti("93545180").subscribe(
      res => {
        console.log(res);
        this.rec=res;
      });
  }

}
